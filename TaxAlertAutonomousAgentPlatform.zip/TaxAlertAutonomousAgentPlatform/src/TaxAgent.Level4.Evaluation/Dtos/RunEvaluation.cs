namespace TaxAgent.Level4.Evaluation.Dtos;

public sealed class RunEvaluation
{
    public string CaseId { get; set; } = string.Empty;
    public string RunId { get; set; } = string.Empty;
    public string WorkflowVersion { get; set; } = string.Empty;
    public string AdvisorPromptVersion { get; set; } = string.Empty;
    public string DeliverablePromptVersion { get; set; } = string.Empty;
    public string ReviewerPromptVersion { get; set; } = string.Empty;
    public string RoutingPolicyVersion { get; set; } = string.Empty;
    public string MemoryPolicyVersion { get; set; } = string.Empty;

    public string ReviewDecision { get; set; } = string.Empty;
    public string HumanOutcome { get; set; } = string.Empty;

    public double FeedbackScore { get; set; }
    public double Factuality { get; set; }
    public double Completeness { get; set; }
    public double Actionability { get; set; }
    public double ClientReadiness { get; set; }
    public double ReferenceQuality { get; set; }

    public int RevisionCount { get; set; }
    public int NeedMoreInfoCount { get; set; }
    public double TimeToApproveMinutes { get; set; }

    public string InputArtifactPath { get; set; } = string.Empty;
    public string AdvisorArtifactPath { get; set; } = string.Empty;
    public string DeliverableArtifactPath { get; set; } = string.Empty;
    public string ReviewArtifactPath { get; set; } = string.Empty;
    public string? FinalDocxPath { get; set; }

    public List<string> Issues { get; set; } = [];
}

public sealed class EvaluationInput
{
    public string CaseId { get; set; } = string.Empty;
    public string RunId { get; set; } = string.Empty;
    public string InputArtifactPath { get; set; } = string.Empty;
    public string AdvisorArtifactPath { get; set; } = string.Empty;
    public string DeliverableArtifactPath { get; set; } = string.Empty;
    public string ReviewArtifactPath { get; set; } = string.Empty;
    public string? FinalDocxPath { get; set; }
}

public sealed class EvaluationQuery
{
    public DateTimeOffset? StartUtc { get; set; }
    public DateTimeOffset? EndUtc { get; set; }
    public string? TenantId { get; set; }
    public string? ClientId { get; set; }
}
