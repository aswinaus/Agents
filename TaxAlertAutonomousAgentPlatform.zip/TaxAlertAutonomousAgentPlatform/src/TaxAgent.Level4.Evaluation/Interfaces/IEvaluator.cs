using TaxAgent.Level4.Evaluation.Dtos;

namespace TaxAgent.Level4.Evaluation.Interfaces;

public interface IEvaluator
{
    Task<RunEvaluation> EvaluateAsync(EvaluationInput input, CancellationToken cancellationToken);
}
