using TaxAgent.Level4.Evaluation.Dtos;

namespace TaxAgent.Level4.Evaluation.Interfaces;

public interface IEvaluationStore
{
    Task SaveAsync(RunEvaluation evaluation, CancellationToken cancellationToken);
    Task<IReadOnlyList<RunEvaluation>> QueryAsync(EvaluationQuery query, CancellationToken cancellationToken);
}
