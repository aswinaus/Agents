using TaxAgent.Level4.Evaluation.Dtos;
using TaxAgent.Level4.Evaluation.Interfaces;

namespace TaxAgent.Level4.Evaluation.Services;

public sealed class WeightedScoreEvaluator : IEvaluator
{
    public Task<RunEvaluation> EvaluateAsync(EvaluationInput input, CancellationToken cancellationToken)
    {
        // Skeleton for Level 4. Replace with Foundry evaluators or your own rubric logic.
        var evaluation = new RunEvaluation
        {
            CaseId = input.CaseId,
            RunId = input.RunId,
            InputArtifactPath = input.InputArtifactPath,
            AdvisorArtifactPath = input.AdvisorArtifactPath,
            DeliverableArtifactPath = input.DeliverableArtifactPath,
            ReviewArtifactPath = input.ReviewArtifactPath,
            FinalDocxPath = input.FinalDocxPath,
            WorkflowVersion = "level3-v1",
            AdvisorPromptVersion = "advisor-v1",
            DeliverablePromptVersion = "deliverable-v1",
            ReviewerPromptVersion = "reviewer-v1",
            RoutingPolicyVersion = "routing-v1",
            MemoryPolicyVersion = "memory-v1",
            ReviewDecision = "PendingHumanOutcome",
            HumanOutcome = "Pending",
            Factuality = 0,
            Completeness = 0,
            Actionability = 0,
            ClientReadiness = 0,
            ReferenceQuality = 0,
            FeedbackScore = 0
        };

        return Task.FromResult(evaluation);
    }
}
