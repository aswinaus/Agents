using System.Text.Json;
using TaxAgent.Level4.Evaluation.Dtos;
using TaxAgent.Level4.Evaluation.Interfaces;

namespace TaxAgent.Level4.Evaluation.Services;

public sealed class BlobJsonEvaluationStore(string rootPath) : IEvaluationStore
{
    public async Task SaveAsync(RunEvaluation evaluation, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(rootPath);
        var path = Path.Combine(rootPath, $"{evaluation.RunId}.evaluation.json");
        await using var stream = File.Create(path);
        await JsonSerializer.SerializeAsync(stream, evaluation, cancellationToken: cancellationToken, options: JsonOptions.Default);
    }

    public Task<IReadOnlyList<RunEvaluation>> QueryAsync(EvaluationQuery query, CancellationToken cancellationToken)
    {
        IReadOnlyList<RunEvaluation> empty = [];
        return Task.FromResult(empty);
    }
}

internal static class JsonOptions
{
    public static readonly JsonSerializerOptions Default = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };
}
