namespace TaxAgent.Level5.RL.Dtos;

public sealed class RlTrajectory
{
    public string CaseId { get; set; } = string.Empty;
    public string RunId { get; set; } = string.Empty;
    public List<RlStep> Steps { get; set; } = [];
    public double FinalReward { get; set; }
}

public sealed class RlStep
{
    public int StepNumber { get; set; }
    public string Actor { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string StateSummary { get; set; } = string.Empty;
    public string ObservationArtifactPath { get; set; } = string.Empty;
    public double? StepReward { get; set; }
}

public sealed class PolicyVersion
{
    public string PolicyVersionId { get; set; } = Guid.NewGuid().ToString("N");
    public string PolicyType { get; set; } = string.Empty;
    public string VersionLabel { get; set; } = string.Empty;
    public string ArtifactPath { get; set; } = string.Empty;
    public bool IsActive { get; set; }
}

public sealed class PolicyTrainingResult
{
    public string CandidatePolicyVersionId { get; set; } = string.Empty;
    public string MetricsArtifactPath { get; set; } = string.Empty;
}
