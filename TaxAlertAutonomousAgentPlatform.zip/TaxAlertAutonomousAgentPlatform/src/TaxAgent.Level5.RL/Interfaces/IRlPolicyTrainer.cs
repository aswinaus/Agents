using TaxAgent.Level5.RL.Dtos;

namespace TaxAgent.Level5.RL.Interfaces;

public interface IRlPolicyTrainer
{
    Task<PolicyTrainingResult> TrainAsync(IReadOnlyList<RlTrajectory> trajectories, CancellationToken cancellationToken);
}
