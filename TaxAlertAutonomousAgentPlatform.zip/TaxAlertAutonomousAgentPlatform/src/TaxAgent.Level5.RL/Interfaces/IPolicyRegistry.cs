using TaxAgent.Level5.RL.Dtos;

namespace TaxAgent.Level5.RL.Interfaces;

public interface IPolicyRegistry
{
    Task<PolicyVersion?> GetActiveAsync(string policyType, CancellationToken cancellationToken);
    Task RegisterCandidateAsync(PolicyVersion version, CancellationToken cancellationToken);
    Task PromoteAsync(string policyVersionId, CancellationToken cancellationToken);
}
