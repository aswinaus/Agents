using TaxAgent.Level5.RL.Dtos;

namespace TaxAgent.Level5.RL.Interfaces;

public interface ITrajectoryBuilder
{
    Task<RlTrajectory> BuildAsync(string caseId, string runId, CancellationToken cancellationToken);
}
