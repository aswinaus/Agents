using TaxAgent.Level5.RL.Dtos;
using TaxAgent.Level5.RL.Interfaces;

namespace TaxAgent.Level5.RL.Services;

public sealed class InMemoryPolicyRegistry : IPolicyRegistry
{
    private readonly Dictionary<string, PolicyVersion> _active = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, PolicyVersion> _all = new(StringComparer.OrdinalIgnoreCase);

    public Task<PolicyVersion?> GetActiveAsync(string policyType, CancellationToken cancellationToken)
    {
        _active.TryGetValue(policyType, out var value);
        return Task.FromResult(value);
    }

    public Task RegisterCandidateAsync(PolicyVersion version, CancellationToken cancellationToken)
    {
        _all[version.PolicyVersionId] = version;
        return Task.CompletedTask;
    }

    public Task PromoteAsync(string policyVersionId, CancellationToken cancellationToken)
    {
        if (_all.TryGetValue(policyVersionId, out var version))
        {
            version.IsActive = true;
            _active[version.PolicyType] = version;
        }

        return Task.CompletedTask;
    }
}
