using TaxAgent.Level5.RL.Dtos;
using TaxAgent.Level5.RL.Interfaces;

namespace TaxAgent.Level5.RL.Services;

public sealed class JsonTrajectoryBuilder : ITrajectoryBuilder
{
    public Task<RlTrajectory> BuildAsync(string caseId, string runId, CancellationToken cancellationToken)
    {
        var trajectory = new RlTrajectory
        {
            CaseId = caseId,
            RunId = runId
        };

        return Task.FromResult(trajectory);
    }
}
