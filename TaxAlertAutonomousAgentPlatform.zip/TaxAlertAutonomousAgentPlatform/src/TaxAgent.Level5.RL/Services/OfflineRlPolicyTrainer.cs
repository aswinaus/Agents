using TaxAgent.Level5.RL.Dtos;
using TaxAgent.Level5.RL.Interfaces;

namespace TaxAgent.Level5.RL.Services;

public sealed class OfflineRlPolicyTrainer : IRlPolicyTrainer
{
    public Task<PolicyTrainingResult> TrainAsync(IReadOnlyList<RlTrajectory> trajectories, CancellationToken cancellationToken)
    {
        var result = new PolicyTrainingResult
        {
            CandidatePolicyVersionId = Guid.NewGuid().ToString("N"),
            MetricsArtifactPath = "not-implemented.json"
        };

        return Task.FromResult(result);
    }
}
