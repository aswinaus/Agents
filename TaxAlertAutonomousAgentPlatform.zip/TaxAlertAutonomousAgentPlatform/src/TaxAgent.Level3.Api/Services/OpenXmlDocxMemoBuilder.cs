using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.Extensions.Options;
using TaxAgent.Level3.Api.Contracts;
using TaxAgent.Level3.Api.Options;
using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Services;

public sealed class OpenXmlDocxMemoBuilder(IOptions<StorageOptions> options) : IDocxMemoBuilder
{
    private readonly string _root = options.Value.RootPath;

    public Task<string> BuildAsync(string caseId, DeliverableMemo memo, CancellationToken cancellationToken)
    {
        var folder = Path.Combine(_root, "docx");
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"{caseId}.memo.docx");

        using var document = WordprocessingDocument.Create(path, WordprocessingDocumentType.Document);
        var mainPart = document.AddMainDocumentPart();
        mainPart.Document = new Document(new Body());
        var body = mainPart.Document.Body!;

        AddHeading(body, memo.Title);
        AddSection(body, "Executive Summary", memo.ExecutiveSummary);
        AddSection(body, "Background", memo.Background);
        AddSection(body, "OECD Update Summary", memo.OecdUpdates.Summary);
        AddBullets(body, "OECD Key Changes", memo.OecdUpdates.KeyChanges);
        AddSection(body, "Implications", memo.Implications);
        AddBullets(body, "Recommendations", memo.Recommendations.Select(x => $"[{x.Priority}] {x.Recommendation} — {x.Rationale}").ToList());
        AddSection(body, "Implementation Notes", memo.ImplementationNotes);
        AddSection(body, "Conclusion", memo.Conclusion);
        AddBullets(body, "References", memo.References);
        AddBullets(body, "Assumptions Used", memo.AssumptionsUsed);

        mainPart.Document.Save();
        return Task.FromResult(path);
    }

    private static void AddHeading(Body body, string text)
        => body.AppendChild(new Paragraph(new Run(new Text(text)))
        {
            ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Heading1" })
        });

    private static void AddSection(Body body, string title, string content)
    {
        body.AppendChild(new Paragraph(new Run(new Text(title)))
        {
            ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Heading2" })
        });
        body.AppendChild(new Paragraph(new Run(new Text(content ?? string.Empty))));
    }

    private static void AddBullets(Body body, string title, IEnumerable<string> items)
    {
        AddSection(body, title, string.Empty);
        foreach (var item in items.Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            body.AppendChild(new Paragraph(new Run(new Text($"• {item}"))));
        }
    }
}
