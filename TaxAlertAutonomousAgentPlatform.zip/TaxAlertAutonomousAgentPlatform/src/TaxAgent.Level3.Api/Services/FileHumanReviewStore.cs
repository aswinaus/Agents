using TaxAgent.Level3.Api.Contracts;
using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Services;

public sealed class FileHumanReviewStore(IArtifactStore artifactStore) : IHumanReviewStore
{
    public Task<string> CreateNeedMoreInfoTaskAsync(KnowledgeInput input, AdvisorDecision decision, CancellationToken cancellationToken)
    {
        var id = Guid.NewGuid().ToString("N");
        return artifactStore.SaveJsonAsync($"human-review/{id}.need-more-info.json", new { input, decision }, cancellationToken);
    }

    public Task<string> CreateReviewTaskAsync(KnowledgeInput input, DeliverableMemo memo, ReviewDecision review, CancellationToken cancellationToken)
    {
        var id = Guid.NewGuid().ToString("N");
        return artifactStore.SaveJsonAsync($"human-review/{id}.review.json", new { input, memo, review }, cancellationToken);
    }

    public Task<string> CreateEscalationTaskAsync(KnowledgeInput input, DeliverableMemo memo, ReviewDecision review, CancellationToken cancellationToken)
    {
        var id = Guid.NewGuid().ToString("N");
        return artifactStore.SaveJsonAsync($"human-review/{id}.escalation.json", new { input, memo, review }, cancellationToken);
    }
}
