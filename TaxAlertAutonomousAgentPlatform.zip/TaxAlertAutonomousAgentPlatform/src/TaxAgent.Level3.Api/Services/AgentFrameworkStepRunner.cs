using Microsoft.Agents.AI;
using TaxAgent.Level3.Api.Contracts;

namespace TaxAgent.Level3.Api.Services;

public sealed class AgentFrameworkStepRunner(IServiceProvider serviceProvider) : IAgentStepRunner
{
    public async Task<string> RunAgentAsync(string agentName, string inputJson, CancellationToken cancellationToken)
    {
        var agent = serviceProvider.GetRequiredKeyedService<AIAgent>(agentName);
        var result = await agent.RunAsync(inputJson, cancellationToken: cancellationToken);
        return result.ToString();
    }
}
