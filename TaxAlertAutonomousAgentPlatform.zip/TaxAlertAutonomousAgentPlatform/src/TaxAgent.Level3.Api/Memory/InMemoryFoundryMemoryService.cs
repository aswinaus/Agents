using TaxAgent.Level3.Api.Contracts;
using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Memory;

public sealed class InMemoryFoundryMemoryService : IMemoryService
{
    private readonly List<MemoryItem> _items = [];

    public Task<IReadOnlyList<MemoryItem>> RecallAsync(MemoryQuery query, CancellationToken cancellationToken)
    {
        var result = _items
            .Where(x => string.IsNullOrWhiteSpace(query.ClientId) || x.Metadata.GetValueOrDefault("clientId") == query.ClientId)
            .Where(x => string.IsNullOrWhiteSpace(query.Topic) || x.Content.Contains(query.Topic, StringComparison.OrdinalIgnoreCase))
            .Take(5)
            .ToList();

        return Task.FromResult<IReadOnlyList<MemoryItem>>(result);
    }

    public Task WriteApprovedLearningAsync(MemoryWriteRequest request, CancellationToken cancellationToken)
    {
        _items.Add(new MemoryItem
        {
            Category = request.Category,
            Title = request.Title,
            Content = request.Content,
            Source = request.Source,
            Metadata = new Dictionary<string, string>(request.Metadata)
            {
                ["clientId"] = request.ClientId,
                ["tenantId"] = request.TenantId,
                ["caseId"] = request.CaseId
            }
        });

        return Task.CompletedTask;
    }
}
