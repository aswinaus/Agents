using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Contracts;

public interface IMemoryService
{
    Task<IReadOnlyList<MemoryItem>> RecallAsync(MemoryQuery query, CancellationToken cancellationToken);
    Task WriteApprovedLearningAsync(MemoryWriteRequest request, CancellationToken cancellationToken);
}
