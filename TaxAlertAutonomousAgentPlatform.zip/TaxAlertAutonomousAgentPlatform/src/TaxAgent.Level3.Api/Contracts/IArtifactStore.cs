namespace TaxAgent.Level3.Api.Contracts;

public interface IArtifactStore
{
    Task<string> SaveTextAsync(string relativePath, string content, CancellationToken cancellationToken);
    Task<string> SaveJsonAsync<T>(string relativePath, T value, CancellationToken cancellationToken);
    Task<T?> ReadJsonAsync<T>(string absolutePath, CancellationToken cancellationToken);
}
