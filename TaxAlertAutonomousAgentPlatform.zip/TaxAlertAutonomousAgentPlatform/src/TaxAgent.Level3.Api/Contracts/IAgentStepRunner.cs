namespace TaxAgent.Level3.Api.Contracts;

public interface IAgentStepRunner
{
    Task<string> RunAgentAsync(string agentName, string inputJson, CancellationToken cancellationToken);
}
