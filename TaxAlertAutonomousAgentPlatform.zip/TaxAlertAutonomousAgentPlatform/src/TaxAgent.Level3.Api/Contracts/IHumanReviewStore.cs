using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Contracts;

public interface IHumanReviewStore
{
    Task<string> CreateNeedMoreInfoTaskAsync(KnowledgeInput input, AdvisorDecision decision, CancellationToken cancellationToken);
    Task<string> CreateReviewTaskAsync(KnowledgeInput input, DeliverableMemo memo, ReviewDecision review, CancellationToken cancellationToken);
    Task<string> CreateEscalationTaskAsync(KnowledgeInput input, DeliverableMemo memo, ReviewDecision review, CancellationToken cancellationToken);
}
