using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Contracts;

public interface ILevel3WorkflowRunner
{
    Task<WorkflowRunResult> RunAsync(KnowledgeInput input, CancellationToken cancellationToken);
}
