using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Contracts;

public interface IDocxMemoBuilder
{
    Task<string> BuildAsync(string caseId, DeliverableMemo memo, CancellationToken cancellationToken);
}
