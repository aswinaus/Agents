using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Contracts;

public interface IWorkflowStateStore
{
    Task SaveAsync(CaseState state, CancellationToken cancellationToken);
    Task<CaseState?> GetAsync(string caseId, CancellationToken cancellationToken);
}
