using System.Text.Json;
using Microsoft.Agents.AI;
using TaxAgent.Level3.Api.Contracts;
using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Endpoints;

public static class Level3Endpoints
{
    public static IEndpointRouteBuilder MapLevel3Endpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/", () => Results.Ok(new { name = "Tax Alert Autonomous Agent Platform", status = "running" }));

        app.MapPost("/api/messages", async (
            KnowledgeInput input,
            ILevel3WorkflowRunner runner,
            CancellationToken cancellationToken) =>
        {
            var result = await runner.RunAsync(input, cancellationToken);
            return Results.Ok(result);
        });

        // Backward-compatible alias during transition from /api/level3/run.
        app.MapPost("/api/level3/run", async (
            KnowledgeInput input,
            ILevel3WorkflowRunner runner,
            CancellationToken cancellationToken) =>
        {
            var result = await runner.RunAsync(input, cancellationToken);
            return Results.Ok(result);
        });

        app.MapPost("/api/level3/groupchat", async (
            KnowledgeInput input,
            IServiceProvider serviceProvider,
            CancellationToken cancellationToken) =>
        {
            var workflowAgent = serviceProvider.GetRequiredKeyedService<AIAgent>("tax-level3-groupchat");
            var result = await workflowAgent.RunAsync(JsonSerializer.Serialize(input), cancellationToken: cancellationToken);
            return Results.Ok(new
            {
                caseId = input.CaseId,
                output = result.ToString()
            });
        });

        return app;
    }
}
