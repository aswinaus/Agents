using Azure;
using Azure.AI.OpenAI;
using Azure.Identity;
using Azure.Monitor.OpenTelemetry.AspNetCore;
using Microsoft.Agents.A365.Observability.Extensions.AgentFramework;
using Microsoft.Agents.A365.Observability.Runtime;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Options;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting;
using Microsoft.Agents.AI.Workflows;
using TaxAgent.Level3.Api.Contracts;
using TaxAgent.Level3.Api.Endpoints;
using TaxAgent.Level3.Api.Memory;
using TaxAgent.Level3.Api.Options;
using TaxAgent.Level3.Api.Prompts;
using TaxAgent.Level3.Api.Services;
using TaxAgent.Level3.Api.Storage;
using TaxAgent.Level4.Evaluation.Interfaces;
using TaxAgent.Level4.Evaluation.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<AzureOpenAiOptions>(builder.Configuration.GetSection("AzureOpenAI"));
builder.Services.Configure<StorageOptions>(builder.Configuration.GetSection("Storage"));

builder.Services.AddMemoryCache();
builder.Services.AddHttpClient("a365-token");

builder.Services.AddSingleton<IChatClient>(sp =>
{
    var options = sp.GetRequiredService<IOptions<AzureOpenAiOptions>>().Value;

    var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT") ?? options.Endpoint;
    var deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_MODEL") ?? options.DeploymentName;
    var key = Environment.GetEnvironmentVariable("AZURE_OPENAI_KEY");

    if (string.IsNullOrWhiteSpace(endpoint) || string.IsNullOrWhiteSpace(deploymentName))
    {
        throw new InvalidOperationException("Azure OpenAI configuration is missing. Set AzureOpenAI:Endpoint and AzureOpenAI:DeploymentName or environment variables AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_MODEL.");
    }

    AzureOpenAIClient client;
    if (!string.IsNullOrWhiteSpace(key))
    {
        client = new AzureOpenAIClient(new Uri(endpoint), new AzureKeyCredential(key));
    }
    else
    {
        client = new AzureOpenAIClient(new Uri(endpoint), new ManagedIdentityCredential());
    }

    return client
        .GetChatClient(deploymentName)
        .AsIChatClient()
        .AsBuilder()
        .UseOpenTelemetry(sourceName: "TaxAlertAutonomousAgentPlatform", configure: cfg => cfg.EnableSensitiveData = false)
        .Build();
});

builder.Services.AddSingleton<IArtifactStore, FileArtifactStore>();
builder.Services.AddSingleton<IWorkflowStateStore, FileWorkflowStateStore>();
builder.Services.AddSingleton<IHumanReviewStore, FileHumanReviewStore>();
builder.Services.AddSingleton<IMemoryService, InMemoryFoundryMemoryService>();
builder.Services.AddSingleton<IDocxMemoBuilder, OpenXmlDocxMemoBuilder>();
builder.Services.AddSingleton<IAgentStepRunner, AgentFrameworkStepRunner>();
builder.Services.AddSingleton<ILevel3WorkflowRunner, Level3WorkflowRunner>();

builder.Services.AddSingleton<ObservabilityTokenProvider>();
builder.Services.AddSingleton(sp =>
{
    var tokenProvider = sp.GetRequiredService<ObservabilityTokenProvider>();
    return new Agent365ExporterOptions
    {
        ClusterCategory = builder.Configuration["Agent365:ClusterCategory"] ?? "prod",
        TokenResolver = async (agentId, tenantId) => await tokenProvider.GetObservabilityTokenAsync(agentId, tenantId)
    };
});

builder.Services.AddSingleton<IEvaluationStore>(sp =>
{
    var storage = sp.GetRequiredService<IOptions<StorageOptions>>().Value;
    return new BlobJsonEvaluationStore(Path.Combine(storage.RootPath, "evaluations"));
});
builder.Services.AddSingleton<IEvaluator, WeightedScoreEvaluator>();

builder.Services.AddOpenTelemetry()
    .WithTracing(tracing =>
    {
        tracing.AddSource("Microsoft.Agents.*");
        tracing.AddSource("Microsoft.Extensions.AI");
    })
    .UseAzureMonitor(options =>
    {
        options.ConnectionString = builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"];
    });

builder.AddA365Tracing();
builder.Services.AddTracing(config => config.WithAgentFramework());

builder.AddAIAgent(
    "advisor",
    instructions: PromptCatalog.TaxAdvisorPrompt,
    description: "Assesses if the tax package is sufficient and emits bounded JSON.")
    .WithInMemorySessionStore();

builder.AddAIAgent(
    "deliverable",
    instructions: PromptCatalog.DeliverablePrompt,
    description: "Builds the memo JSON.")
    .WithInMemorySessionStore();

builder.AddAIAgent(
    "reviewer",
    instructions: PromptCatalog.ReviewPrompt,
    description: "Approves, rejects, or requests critical missing information.")
    .WithInMemorySessionStore();

builder.AddWorkflow("tax-level3-groupchat", (sp, key) =>
{
    var advisor = sp.GetRequiredKeyedService<AIAgent>("advisor");
    var deliverable = sp.GetRequiredKeyedService<AIAgent>("deliverable");
    var reviewer = sp.GetRequiredKeyedService<AIAgent>("reviewer");

    return AgentWorkflowBuilder
        .CreateGroupChatBuilderWith(agents => new RoundRobinGroupChatManager(agents)
        {
            MaximumIterationCount = 4
        })
        .AddParticipants(advisor, deliverable, reviewer)
        .Build();
}).AddAsAIAgent();

var app = builder.Build();
app.MapLevel3Endpoints();
app.Run();
