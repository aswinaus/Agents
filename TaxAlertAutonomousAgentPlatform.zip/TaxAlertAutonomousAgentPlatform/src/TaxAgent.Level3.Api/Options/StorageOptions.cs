namespace TaxAgent.Level3.Api.Options;

public sealed class StorageOptions
{
    public string RootPath { get; set; } = Path.Combine(AppContext.BaseDirectory, "data");
}
