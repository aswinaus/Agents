using System.Text.Json;
using Microsoft.Extensions.Options;
using TaxAgent.Level3.Api.Contracts;
using TaxAgent.Level3.Api.Options;

namespace TaxAgent.Level3.Api.Storage;

public sealed class FileArtifactStore(IOptions<StorageOptions> options) : IArtifactStore
{
    private readonly string _root = options.Value.RootPath;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    public async Task<string> SaveTextAsync(string relativePath, string content, CancellationToken cancellationToken)
    {
        var absolutePath = GetAbsolutePath(relativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(absolutePath)!);
        await File.WriteAllTextAsync(absolutePath, content, cancellationToken);
        return absolutePath;
    }

    public async Task<string> SaveJsonAsync<T>(string relativePath, T value, CancellationToken cancellationToken)
    {
        var absolutePath = GetAbsolutePath(relativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(absolutePath)!);
        await using var stream = File.Create(absolutePath);
        await JsonSerializer.SerializeAsync(stream, value, JsonOptions, cancellationToken);
        return absolutePath;
    }

    public async Task<T?> ReadJsonAsync<T>(string absolutePath, CancellationToken cancellationToken)
    {
        if (!File.Exists(absolutePath))
        {
            return default;
        }

        await using var stream = File.OpenRead(absolutePath);
        return await JsonSerializer.DeserializeAsync<T>(stream, JsonOptions, cancellationToken);
    }

    private string GetAbsolutePath(string relativePath) => Path.Combine(_root, relativePath.Replace('/', Path.DirectorySeparatorChar));
}
