using Microsoft.Extensions.Options;
using TaxAgent.Level3.Api.Contracts;
using TaxAgent.Level3.Api.Options;
using TaxAgent.Platform.Contracts.Dtos;

namespace TaxAgent.Level3.Api.Storage;

public sealed class FileWorkflowStateStore(IArtifactStore artifactStore, IOptions<StorageOptions> options) : IWorkflowStateStore
{
    private readonly string _stateFolder = Path.Combine(options.Value.RootPath, "state");

    public Task SaveAsync(CaseState state, CancellationToken cancellationToken)
        => artifactStore.SaveJsonAsync($"state/{state.CaseId}.state.json", state, cancellationToken);

    public Task<CaseState?> GetAsync(string caseId, CancellationToken cancellationToken)
        => artifactStore.ReadJsonAsync<CaseState>(Path.Combine(_stateFolder, $"{caseId}.state.json"), cancellationToken);
}
