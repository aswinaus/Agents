namespace TaxAgent.Platform.Contracts.Dtos;

public sealed class AdvisorDecision
{
    public string Action { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
    public List<string> Assumptions { get; set; } = [];
    public List<string> MissingFields { get; set; } = [];
    public DeliverableInstructions? DeliverableInstructions { get; set; }
}

public sealed class DeliverableInstructions
{
    public string ClientContext { get; set; } = string.Empty;
    public List<string> KeyIssues { get; set; } = [];
    public string AdvisoryPosition { get; set; } = string.Empty;
    public List<string> Assumptions { get; set; } = [];
    public List<string> PriorityActions { get; set; } = [];
}
