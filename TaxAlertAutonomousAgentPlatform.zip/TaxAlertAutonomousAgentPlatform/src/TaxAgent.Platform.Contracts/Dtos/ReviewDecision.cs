namespace TaxAgent.Platform.Contracts.Dtos;

public sealed class ReviewDecision
{
    public string Decision { get; set; } = string.Empty;
    public string Comments { get; set; } = string.Empty;
    public List<string> RequiredInfo { get; set; } = [];
    public List<string> RevisionInstructions { get; set; } = [];
    public string ReviewerRole { get; set; } = "HumanReviewGate";
}
