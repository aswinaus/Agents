namespace TaxAgent.Platform.Contracts.Dtos;

public sealed class DeliverableMemo
{
    public string Title { get; set; } = string.Empty;
    public string ExecutiveSummary { get; set; } = string.Empty;
    public string Background { get; set; } = string.Empty;
    public OecdUpdates OecdUpdates { get; set; } = new();
    public string Implications { get; set; } = string.Empty;
    public List<RecommendationItem> Recommendations { get; set; } = [];
    public string ImplementationNotes { get; set; } = string.Empty;
    public string Conclusion { get; set; } = string.Empty;
    public List<string> References { get; set; } = [];
    public List<string> AssumptionsUsed { get; set; } = [];
}
