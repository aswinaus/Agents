namespace TaxAgent.Platform.Contracts.Dtos;

public sealed class CaseState
{
    public string CaseId { get; set; } = string.Empty;
    public string TenantId { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public int RevisionCount { get; set; }
    public int NeedMoreInfoCount { get; set; }
    public string? CurrentMemoJsonPath { get; set; }
    public string? CurrentReviewJsonPath { get; set; }
    public string? FinalDocxPath { get; set; }
    public DateTimeOffset CreatedUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;
}
