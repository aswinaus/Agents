namespace TaxAgent.Platform.Contracts.Dtos;

public sealed class KnowledgeInput
{
    public string CaseId { get; set; } = Guid.NewGuid().ToString("N");
    public string TenantId { get; set; } = "default-tenant";
    public string ClientId { get; set; } = string.Empty;
    public string ConversationId { get; set; } = Guid.NewGuid().ToString("N");
    public string CorrelationId { get; set; } = Guid.NewGuid().ToString("N");

    public string Title { get; set; } = string.Empty;
    public string ExecutiveSummary { get; set; } = string.Empty;
    public string Background { get; set; } = string.Empty;
    public OecdUpdates OecdUpdates { get; set; } = new();
    public string Implications { get; set; } = string.Empty;
    public List<RecommendationItem> Recommendations { get; set; } = [];
    public string ImplementationNotes { get; set; } = string.Empty;
    public string Conclusion { get; set; } = string.Empty;
    public List<string> References { get; set; } = [];
    public string ClientContext { get; set; } = string.Empty;
    public Dictionary<string, string> AdditionalMetadata { get; set; } = new();
}

public sealed class OecdUpdates
{
    public string Summary { get; set; } = string.Empty;
    public List<string> KeyChanges { get; set; } = [];
}

public sealed class RecommendationItem
{
    public string Recommendation { get; set; } = string.Empty;
    public string Rationale { get; set; } = string.Empty;
    public string Priority { get; set; } = "Medium";
}
