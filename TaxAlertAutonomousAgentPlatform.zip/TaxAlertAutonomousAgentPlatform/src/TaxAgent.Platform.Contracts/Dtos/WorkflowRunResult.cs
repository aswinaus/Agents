namespace TaxAgent.Platform.Contracts.Dtos;

public sealed class WorkflowRunResult
{
    public string CaseId { get; set; } = string.Empty;
    public string RunId { get; set; } = Guid.NewGuid().ToString("N");
    public string Status { get; set; } = string.Empty;
    public string? AdvisorArtifactPath { get; set; }
    public string? DeliverableArtifactPath { get; set; }
    public string? ReviewArtifactPath { get; set; }
    public string? MemoDocxPath { get; set; }
    public string? ReviewTaskId { get; set; }
}
