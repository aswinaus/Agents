# Tax Alert Autonomous Agent Platform (.NET 9)

This solution contains:

- **Level 3 operational agent** in `TaxAgent.Level3.Api`
  - Microsoft Agent Framework agents
  - bounded production workflow runner
  - bounded group chat workflow for experimentation
  - `/api/messages` endpoint for Copilot Studio custom connector / agent calls
  - Azure Monitor + Agent 365 observability wiring
  - prompt catalog
  - local artifact storage (swap to Blob later)
  - DOCX generation
- **Level 4 skeleton** in `TaxAgent.Level4.Evaluation`
  - DTOs
  - evaluator interfaces
  - JSON evaluation store
- **Level 5 skeleton** in `TaxAgent.Level5.RL`
  - RL DTOs
  - policy registry/trainer interfaces
  - placeholder services

## Solution layout

- `src/TaxAgent.Platform.Contracts`
- `src/TaxAgent.Level3.Api`
- `src/TaxAgent.Level4.Evaluation`
- `src/TaxAgent.Level5.RL`

## Level 3 endpoints

- `POST /api/messages`
  - recommended bounded production path for Copilot Studio
  - invokes Advisor -> Deliverable -> Reviewer with explicit branching
- `POST /api/level3/run`
  - backward-compatible alias to the same bounded runner
- `POST /api/level3/groupchat`
  - sample Agent Framework group-chat workflow
  - useful for experimentation and observability demos

## Configuration

Set these values in `src/TaxAgent.Level3.Api/appsettings.json` or Azure Web App environment variables:

- `AzureOpenAI:Endpoint` or `AZURE_OPENAI_ENDPOINT`
- `AzureOpenAI:DeploymentName` or `AZURE_OPENAI_MODEL`
- `AZURE_OPENAI_KEY` if you are not using managed identity
- `APPLICATIONINSIGHTS_CONNECTION_STRING`
- `Storage:RootPath`
- `ENABLE_A365_OBSERVABILITY_EXPORTER=true`
- `Agent365:StaticToken` or `AGENT365_OBSERVABILITY_TOKEN`
  - or provide `Agent365:TokenEndpoint`

## Notes

- This solution keeps request-scoped Agent 365 context with `BaggageBuilder` in `Level3WorkflowRunner`.
- The Agent 365 exporter and Agent Framework auto-instrumentation are wired in `Program.cs`.
- The explicit `InvokeAgentScope`/`ExecuteToolScope` wrappers are intentionally not forced into this package snapshot because the preview API surface can drift across beta builds. The current solution is designed to stay compile-safer while keeping the extension point obvious.
- For production, replace `FileArtifactStore` with Blob Storage and replace the placeholder/static token approach with your real Agent 365 token acquisition flow.

## Run

```bash
cd src/TaxAgent.Level3.Api
dotnet restore
dotnet run
```

## Sample request

```json
{
  "caseId": "taxalert-001",
  "tenantId": "tenant-a",
  "clientId": "client-77",
  "conversationId": "conv-001",
  "correlationId": "corr-001",
  "title": "New Zealand transfer pricing alert",
  "executiveSummary": "A new transfer pricing update affects documentation expectations.",
  "background": "The update matters because the client has cross-border intercompany transactions.",
  "oecdUpdates": {
    "summary": "The update increases emphasis on contemporaneous documentation.",
    "keyChanges": [
      "Documentation expectations expanded",
      "Risk areas for intercompany arrangements highlighted"
    ]
  },
  "implications": "There may be increased documentation and governance requirements.",
  "recommendations": [
    {
      "recommendation": "Refresh documentation",
      "rationale": "Helps align with current expectations",
      "priority": "High"
    }
  ],
  "implementationNotes": "Coordinate with tax, finance, and legal stakeholders.",
  "conclusion": "Immediate review is recommended.",
  "references": [
    "Knowledge Agent input"
  ],
  "clientContext": "Client operates in New Zealand and has material intercompany services flows."
}
```
