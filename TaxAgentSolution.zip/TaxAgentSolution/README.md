# Tax Agent Solution (.NET 9)

This solution gives you:

- **Level 3 working app** in `TaxAgent.Level3.Api`
  - Microsoft Agent Framework agents
  - bounded group chat workflow
  - bounded production workflow runner
  - Agent 365 observability hooks
  - prompt files
  - local artifact storage
  - DOCX generation
- **Level 4 skeleton** in `TaxAgent.Level4.Evaluation`
  - DTOs
  - evaluator interfaces
  - JSON evaluation store
- **Level 5 skeleton** in `TaxAgent.Level5.RL`
  - DTOs
  - RL interfaces
  - placeholder trainer / policy registry

## Solution layout

- `src/TaxAgent.Platform.Contracts`
- `src/TaxAgent.Level3.Api`
- `src/TaxAgent.Level4.Evaluation`
- `src/TaxAgent.Level5.RL`

## Level 3 endpoints

- `POST /api/level3/run`
  - recommended bounded production path
  - invokes Advisor -> Deliverable -> Reviewer with explicit branching
- `POST /api/level3/groupchat`
  - sample Agent Framework group-chat workflow
  - useful for experimentation and observability demos

## Configuration

Update `src/TaxAgent.Level3.Api/appsettings.json` or environment variables:

- `AzureOpenAI:Endpoint`
- `AzureOpenAI:DeploymentName`
- `APPLICATIONINSIGHTS_CONNECTION_STRING`
- `Storage:RootPath`

For production, replace the placeholder `Agent365TokenProvider` implementation with your real token resolver.

## Notes

This solution is aligned to current Microsoft Learn guidance for:

- `AddAIAgent`, `AddWorkflow`, `AddAsAIAgent`
- group chat via `CreateGroupChatBuilderWith(...)` and `RoundRobinGroupChatManager`
- OpenTelemetry chat-client instrumentation
- Agent 365 `WithAgentFramework()` + `BaggageBuilder`

Because the Agent Framework and Agent 365 packages are preview/beta packages and move quickly, you may need a **small package/API adjustment** when you restore the solution in your environment.

## Run

```bash
cd src/TaxAgent.Level3.Api
dotnet restore
dotnet run
```

## Sample request

```json
{
  "caseId": "taxalert-001",
  "tenantId": "tenant-a",
  "clientId": "client-77",
  "conversationId": "conv-001",
  "correlationId": "corr-001",
  "title": "New Zealand transfer pricing alert",
  "executiveSummary": "A new transfer pricing update affects documentation expectations.",
  "background": "The update matters because the client has cross-border intercompany transactions.",
  "oecdUpdates": {
    "summary": "The update increases emphasis on contemporaneous documentation.",
    "keyChanges": [
      "Documentation expectations expanded",
      "Risk areas for intercompany arrangements highlighted"
    ]
  },
  "implications": "There may be increased documentation and governance requirements.",
  "recommendations": [
    {
      "recommendation": "Refresh documentation",
      "rationale": "Helps align with current expectations",
      "priority": "High"
    }
  ],
  "implementationNotes": "Coordinate with tax, finance, and legal stakeholders.",
  "conclusion": "Immediate review is recommended.",
  "references": [
    "Knowledge Agent input"
  ],
  "clientContext": "Client operates in New Zealand and has material intercompany services flows."
}
```
