namespace TaxAgent.Level3.Api.Services;

public sealed class Agent365TokenProvider
{
    public Task<string> GetObservabilityTokenAsync(string agentId, string tenantId)
    {
        // Replace with real token acquisition for Agent 365 exporter.
        return Task.FromResult("replace-me");
    }
}
